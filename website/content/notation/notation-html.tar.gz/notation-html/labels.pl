# LaTeX2HTML 2002-2-1 (1.71)
# Associate labels original text with physical files.


1;


# LaTeX2HTML 2002-2-1 (1.71)
# labels from external_latex_labels array.


$key = q/tab:thathakaram/;
$external_latex_labels{$key} = q|4|; 
$noresave{$key} = "$nosave";

$key = q/tab:number_letter/;
$external_latex_labels{$key} = q|1|; 
$noresave{$key} = "$nosave";

$key = q/tab:comma/;
$external_latex_labels{$key} = q|2|; 
$noresave{$key} = "$nosave";

$key = q/tab:thathakaram_maelkalam/;
$external_latex_labels{$key} = q|5|; 
$noresave{$key} = "$nosave";

$key = q/tab:example/;
$external_latex_labels{$key} = q|7|; 
$noresave{$key} = "$nosave";

$key = q/tab:use_of_comma/;
$external_latex_labels{$key} = q|3|; 
$noresave{$key} = "$nosave";

$key = q/tab:karvai/;
$external_latex_labels{$key} = q|6|; 
$noresave{$key} = "$nosave";

1;

