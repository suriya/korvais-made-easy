# LaTeX2HTML 2002-2-1 (1.71)
# Associate images original text with physical files.


$key = q/ensuremath{overline{KitaThakaThariThanaKitaThakaThom,}};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="333" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img12.png"
 ALT="\ensuremath{\overline{Kita Thaka Thari Thana Kita Thaka Thom,}}">|; 

$key = q/1_21,_21;_2;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="60" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img13.png"
 ALT="$1_2 1,_2 1;_2$">|; 

$key = q/ensuremath{acute{7}};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="21" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img3.png"
 ALT="\ensuremath{\acute{7}}">|; 

$key = q/ensuremath{acute{8}};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="21" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img4.png"
 ALT="\ensuremath{\acute{8}}">|; 

$key = q/ensuremath{acute{ensuremath{overline{7}}}};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="24" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img11.png"
 ALT="\ensuremath{\acute{\ensuremath{\overline{7}}}}">|; 

$key = q/ensuremath{acute{6}};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="21" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img2.png"
 ALT="\ensuremath{\acute{6}}">|; 

$key = q/ensuremath{acute{ensuremath{overline{3}}}};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="24" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img7.png"
 ALT="\ensuremath{\acute{\ensuremath{\overline{3}}}}">|; 

$key = q/ensuremath{acute{9}};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="21" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img5.png"
 ALT="\ensuremath{\acute{9}}">|; 

$key = q/ensuremath{overline{Kita}};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="38" HEIGHT="17" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img10.png"
 ALT="\ensuremath{\overline{Kita}}">|; 

$key = q/1,_21,_21,_2;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="67" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img15.png"
 ALT="$1,_2 1,_2 1,_2$">|; 

$key = q/ensuremath{acute{5}};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="21" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img1.png"
 ALT="\ensuremath{\acute{5}}">|; 

$key = q/1;_21;_21;_2;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="67" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img14.png"
 ALT="$1;_2 1;_2 1;_2$">|; 

$key = q/1_21_21_2;MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="49" HEIGHT="30" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img16.png"
 ALT="$1_2 1_2 1_2$">|; 

$key = q/ensuremath{overline{ThaThi,KiTaThom}};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="170" HEIGHT="38" ALIGN="MIDDLE" BORDER="0"
 SRC="|."$dir".q|img8.png"
 ALT="\ensuremath{\overline{Tha Thi, Ki Ta Thom}}">|; 

$key = q/ensuremath{acute{ensuremath{overline{5}}}};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="24" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img9.png"
 ALT="\ensuremath{\acute{\ensuremath{\overline{5}}}}">|; 

$key = q/ensuremath{overline{4}};MSF=1.6;AAT/;
$cached_env_img{$key} = q|<IMG
 WIDTH="12" HEIGHT="20" ALIGN="BOTTOM" BORDER="0"
 SRC="|."$dir".q|img6.png"
 ALT="\ensuremath{\overline{4}}">|; 

1;

